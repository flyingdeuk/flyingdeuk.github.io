/*
 *  /MathJax/jax/output/HTML-CSS/fonts/TeX/Fraktur/Bold/PUA.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS["MathJax_Fraktur-bold"],{58113:[630,27,587,64,512],58114:[693,212,394,37,408],58115:[681,219,387,36,384],58116:[473,212,593,67,531],58117:[684,27,393,33,387],58120:[679,220,981,32,875],58121:[717,137,727,17,633]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/Fraktur/Bold/PUA.js");

