MathJax.Hub.Config({
	showMathMenu : false,
	jax : ['input/TeX', 'output/HTML-CSS'],
	extensions : ['tex2jax.js'],
	messageStyle : 'none',
	TeX : {
		extensions : ['AMSmath.js', 'AMSsymbols.js', 'noErrors.js', 'noUndefined.js']
	},
	"HTML-CSS": {
		linebreaks: { 
			automatic: true,
			width: "container"
			}
	}
});
MathJax.Ajax.loadComplete("[MathJax]/config/polydict.js");