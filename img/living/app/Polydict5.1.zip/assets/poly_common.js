function transferSelectedText()
{
    var selText = window.getSelection().toString();

    if (selText && selText.length > 0)
    {
        PolyDict.onTextSelected(selText);
        return;
    }

    // The vertical reader's content is in iframe.

    var iframes = document.getElementsByTagName('iframe');

    for (var i = 0 ; i < iframes.length ; i++)
    {
        var result = getIframeSelectionText(iframes[i]);

        if (result)
        {
            PolyDict.onTextSelected(result);
            return;
        }
    }
}

function getIframeSelectionText(iframe)
{
    var win = iframe.contentWindow;
    var doc = iframe.contentDocument || win.document || iframe.contentWindow.document;

    if (win.getSelection)
    {
        return win.getSelection().toString();
    }
    else if (doc.selection && doc.selection.createRange)
    {
        return doc.selection.createRange().text;
    }
    else if (doc.selection)
    {
        return doc.selection.createRange().text;
    }
}

function calcFrameHeight(ele)
{
	var the_height = ele.contentWindow.document.body.scrollHeight;
	// change the height of the iframe.
	ele.height = the_height;
}

function onExampleClicked(event)
{
    var orgElement = event.target || event.srcElement;

    if (!orgElement)
        return;

    // deep copy. if not, changing <rt> text would change the screen text.
    var element = orgElement.cloneNode(true);

    if (element)
    {
        // remove ruby tag's text to prevent duplicate pronunciation.

        var rp = element.getElementsByTagName('rp');

        for (i = 0; i < rp.length ; i++)
        {
            if (rp[i].textContent)
                rp[i].textContent = "";
            else if (rp[i].innerText)
                rp[i].innerText = "";
        }
                
        var rt = element.getElementsByTagName('rt');

        for (i = 0; i < rt.length ; i++)
        {
            if (rt[i].textContent)
                rt[i].textContent = "";
            else if (rt[i].innerText)
                rt[i].innerText = "";
        }
    }

    var text = element.innerText || element.textContent;

    text = text.trim();
    // alert("Test1: " + text);

    if (text && text.length > 0)
    {
        // alert("Test2: " + text);
        PolyDict.onExampleClicked(text);
    }
}

function polyInit()
{
    var x = document.getElementsByTagName('ex');

    for (i = 0; i < x.length; i++)
    {
        x[i].addEventListener('click', onExampleClicked, false);
    }
}