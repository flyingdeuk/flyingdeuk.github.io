function ___hideAllExcept(id)
{
	if (id == "none")
	{
		makeHtmlVisible();
		return;
	}

	var el = document.getElementById(id);

	// fallback, try to find as class name.
	if (el == null)
	{
		var el2 = document.getElementsByClassName(id);
		if (el2.length > 0)
			el = el2[0];
	}

	// alert(window.screen.width);

	var newMaxWidth = window.screen.width + "px";

	if (el)
	{
		el.style.margin = '0px';
		el.style.padding = '0.2em';
		el.style.maxWidth = newMaxWidth;

		var node = el.parentNode;

		while (node)
		{
			if (node.nodeType == 1)
			{
				node.style.maxWidth = newMaxWidth;
			}

			node = node.parentNode;
		}
	}

	replaceBg(el);

	while (el && el != document.body)
	{
		// go one level up
		var parent = el.parentNode;
		// get siblings of our ancestor
		var siblings = parent.childNodes;
		// loop through the siblings of our ancestor, but skip out actual
		// ancestor
		for (var i = 0, len = siblings.length; i < len; i++)
		{
			var node = siblings[i];
			if (node != el)
			{
				if (node.nodeType == 1)
				{
					// only operate on element nodes
					node.style.display = "none";
				} else if (node.nodeType == 3)
				{
					// wrap text node in span object so we can hide it
					var span = document.createElement("span");
					span.style.display = "none";
					span.className = "xwrap";
					node.parentNode.insertBefore(span, node);
					// Be wary of the dynamic siblings nodeList changing
					// when we add nodes.
					// It actually works here because we add one
					// and remove one so the nodeList stays constant.
					span.appendChild(node);
				}
			}
		}

		el = parent;
	}

	makeHtmlVisible();
}

/*
 * Delimits all images not to
 */
function delimitElementMaxWidths(newMaxWidth)
{
	var newImgMaxWidth = newMaxWidth - 50 + 'px';
	var elements = document.getElementsByTagName('*');

	for (var i = 0; i < elements.length; i++)
	{
		if (elements[i].nodeType == 1 /* elements */)
		{
			var el = elements[i];
			var nodename = el.nodeName.toLowerCase();

			if (nodename.indexOf('img') != -1)
			{
				el.style.maxWidth = newImgMaxWidth;
				el.style.minWidth = '0px';
				
				/* Don't do this: Wikipedia images go invisible. 
				 
				// remove the ad images.
				if (el.className && el.className.indexOf('ad') >= 0)
				{
					el.style.display = 'none';
				} 
				else if (el.src && el.src.indexOf('ad') >= 0)
				{
					el.style.display = 'none';
				}*/

				continue;
			}

			el.style.maxWidth = newMaxWidth + 'px';
			
			// If the minWidth is greater than the maxWidth,
			// the maxWidth does not work. (Naver online dict case.)
			el.style.minWidth = '0px';
			
			// elements[i].style.outline = "thick solid #0000FF";
			// This is important for some pages to delimit the width.
			el.style.left = '0px';
			// el.style.outline = "thick solid #ff0000";
		}
	}
}

function makeHtmlVisible()
{
	var ele = document.getElementsByTagName("html")[0];
	if (ele)
	{
		replaceBg(ele);
	}

	ele = document.getElementsByTagName("body")[0];
	if (ele)
	{
		replaceBg(ele);
		ele.style.visibility = 'visible';
	}

	delimitElementMaxWidths(window.screen.width);
}

function replaceBg(ele)
{
    /* No more custom background replacement.

	if (ele)
	{
		ele.style.backgroundImage = "url('file:///android_asset/snow_noise_tile.png')";
		ele.style.backgroundRepeat = "repeat";
	} */
}
